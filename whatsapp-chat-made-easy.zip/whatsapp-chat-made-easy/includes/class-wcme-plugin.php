<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WCME_Plugin' ) ) {

	class WCME_Plugin {

		const OPTION_NAME = 'wcme_settings';

		private static $instance = null;
		private $admin_hook    = '';
		private $assets_loaded = false;

		public static function instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		private function __construct() {
			add_action( 'init', array( $this, 'load_textdomain' ) );
			add_action( 'admin_menu', array( $this, 'register_admin_menu' ) );
			add_action( 'admin_init', array( $this, 'register_settings' ) );
			add_action( 'admin_enqueue_scripts', array( $this, 'admin_assets' ) );
			add_action( 'wp_enqueue_scripts', array( $this, 'frontend_assets' ) );
			add_action( 'wp_footer', array( $this, 'render_global_button' ), 20 );
			add_shortcode( 'wcme_whatsapp_chat', array( $this, 'shortcode' ) );
			add_filter( 'plugin_action_links_' . plugin_basename( WCME_FILE ), array( $this, 'plugin_action_links' ) );
			add_action( 'widgets_init', array( $this, 'register_widget' ) );
		}

		public static function defaults() {
			return array(
				'enabled'            => 1,
				'button_label'       => __( 'Chat on WhatsApp', 'whatsapp-chat-made-easy' ),
				'headline'           => __( 'Need help?', 'whatsapp-chat-made-easy' ),
				'description'        => __( 'Message our team on WhatsApp and we will reply as soon as possible.', 'whatsapp-chat-made-easy' ),
				'mode'               => 'panel',
				'position'           => 'bottom-right',
				'size'               => 'medium',
				'shape'              => 'rounded',
				'button_style'       => 'classic',
				'icon_style'         => 'classic',
				'icon_source'        => 'plugin_assets',
				'icon_type'          => 'icon_only',
				'animation'          => 'pulse',
				'primary_color'      => '#25D366',
				'hover_color'        => '#1DA851',
				'icon_color'         => '#25D366',
				'text_color'         => '#ffffff',
				'panel_color'        => '#ffffff',
				'panel_text_color'   => '#1f2937',
				'badge_color'        => '#ff5a5f',
				'badge_text'         => '1',
				'show_badge'         => 1,
				'z_index'            => 99999,
				'offset_x'           => 24,
				'offset_y'           => 24,
				'open_delay'         => 0,
				'auto_open'          => 0,
				'allow_mobile'       => 1,
				'allow_desktop'      => 1,
				'link_target'        => '_blank',
				'display_rules'      => 'all',
				'include_post_types' => array( 'post', 'page' ),
				'include_ids'        => '',
				'exclude_ids'        => '',
				'schedule_enabled'   => 0,
				'schedule_days'      => array( 'mon', 'tue', 'wed', 'thu', 'fri' ),
				'schedule_start'     => '09:00',
				'schedule_end'       => '18:00',
				'online_label'       => __( 'We are online', 'whatsapp-chat-made-easy' ),
				'offline_label'      => __( 'Leave a message', 'whatsapp-chat-made-easy' ),
				'offline_message'    => __( 'We are offline right now. Send a message and we will reply during business hours.', 'whatsapp-chat-made-easy' ),
				'custom_css'         => '',
				'contacts'           => array(
					array(
						'enabled'  => 1,
						'name'     => __( 'Support team', 'whatsapp-chat-made-easy' ),
						'phone'    => '15551234567',
						'subtitle' => __( 'Replies in minutes', 'whatsapp-chat-made-easy' ),
						'message'  => __( 'Hi, I need help with {page_title}.', 'whatsapp-chat-made-easy' ),
						'avatar'   => '',
						'color'    => '#25D366',
					),
				),
			);
		}

		public function load_textdomain() {
			load_plugin_textdomain( 'whatsapp-chat-made-easy', false, dirname( plugin_basename( WCME_FILE ) ) . '/languages' );
		}

		public function register_settings() {
			register_setting( 'wcme_settings_group', self::OPTION_NAME, array( $this, 'sanitize_settings' ) );
		}

		public function register_admin_menu() {
			$this->admin_hook = add_options_page(
				__( 'WhatsApp Chat Made Easy', 'whatsapp-chat-made-easy' ),
				__( 'WhatsApp Chat', 'whatsapp-chat-made-easy' ),
				'manage_options',
				'wcme-settings',
				array( $this, 'render_settings_page' )
			);
		}

		public function admin_assets( $hook ) {
			if ( $hook !== $this->admin_hook ) {
				return;
			}

			wp_enqueue_style( 'wp-color-picker' );
			wp_enqueue_style( 'wcme-admin', WCME_URL . 'assets/css/admin.css', array(), WCME_VERSION );
			wp_enqueue_script( 'wcme-admin', WCME_URL . 'assets/js/admin.js', array( 'jquery', 'wp-color-picker' ), WCME_VERSION, true );
		}

		public function frontend_assets() {
			if ( is_admin() ) {
				return;
			}

			if ( $this->assets_loaded ) {
				return;
			}

			$this->assets_loaded = true;
			wp_enqueue_style( 'wcme-frontend', WCME_URL . 'assets/css/frontend.css', array(), WCME_VERSION );
			wp_enqueue_script( 'wcme-frontend', WCME_URL . 'assets/js/frontend.js', array(), WCME_VERSION, true );

			$settings = $this->get_settings();
			if ( ! empty( $settings['custom_css'] ) ) {
				wp_add_inline_style( 'wcme-frontend', $settings['custom_css'] );
			}
		}

		public function plugin_action_links( $links ) {
			$settings_link = '<a href="' . esc_url( admin_url( 'options-general.php?page=wcme-settings' ) ) . '">' . esc_html__( 'Settings', 'whatsapp-chat-made-easy' ) . '</a>';
			array_unshift( $links, $settings_link );

			return $links;
		}

		public function register_widget() {
			register_widget( 'WCME_Widget' );
		}

		public function get_settings( $overrides = array() ) {
			$saved    = get_option( self::OPTION_NAME, array() );
			$settings = wp_parse_args( is_array( $saved ) ? $saved : array(), self::defaults() );

			if ( isset( $settings['icon_color'] ) && in_array( strtolower( (string) $settings['icon_color'] ), array( '#fff', '#ffffff' ), true ) ) {
				$settings['icon_color'] = '#25D366';
			}

			if ( ! empty( $overrides ) ) {
				$settings = wp_parse_args( $overrides, $settings );
			}

			if ( empty( $settings['contacts'] ) || ! is_array( $settings['contacts'] ) ) {
				$settings['contacts'] = self::defaults()['contacts'];
			}

			return $settings;
		}

		public function sanitize_settings( $input ) {
			$input    = wp_unslash( is_array( $input ) ? $input : array() );
			$defaults = self::defaults();
			$output   = $defaults;

			$output['enabled'] = empty( $input['enabled'] ) ? 0 : 1;
			$output['button_label'] = sanitize_text_field( $input['button_label'] ?? $defaults['button_label'] );
			$output['headline'] = sanitize_text_field( $input['headline'] ?? $defaults['headline'] );
			$output['description'] = sanitize_textarea_field( $input['description'] ?? $defaults['description'] );
			$output['mode'] = $this->sanitize_choice( $input['mode'] ?? $defaults['mode'], array( 'panel', 'direct' ), $defaults['mode'] );
			$output['position'] = $this->sanitize_choice( $input['position'] ?? $defaults['position'], array( 'bottom-right', 'bottom-left', 'top-right', 'top-left', 'middle-right', 'middle-left' ), $defaults['position'] );
			$output['size'] = $this->sanitize_choice( $input['size'] ?? $defaults['size'], array( 'small', 'medium', 'large', 'xlarge' ), $defaults['size'] );
			$output['shape'] = $this->sanitize_choice( $input['shape'] ?? $defaults['shape'], array( 'circle', 'rounded', 'pill', 'square' ), $defaults['shape'] );
			$output['button_style'] = $this->sanitize_choice( $input['button_style'] ?? $defaults['button_style'], array( 'classic', 'glass', 'outline', 'minimal', 'solid', 'neon' ), $defaults['button_style'] );
			$output['icon_style'] = $this->sanitize_choice( $input['icon_style'] ?? $defaults['icon_style'], array( 'classic', 'bubble', 'outline', 'minimal', 'solid', 'neon' ), $defaults['icon_style'] );
			$output['icon_source'] = $this->sanitize_choice( $input['icon_source'] ?? $defaults['icon_source'], array( 'plugin_assets', 'inline_svg' ), $defaults['icon_source'] );
			$output['icon_type'] = $this->sanitize_choice( $input['icon_type'] ?? $defaults['icon_type'], array( 'icon_only', 'icon_badge', 'icon_text' ), $defaults['icon_type'] );
			$output['animation'] = $this->sanitize_choice( $input['animation'] ?? $defaults['animation'], array( 'none', 'pulse', 'float', 'bounce', 'glow', 'swing', 'rotate', 'scale', 'wiggle' ), $defaults['animation'] );
			$output['primary_color'] = $this->sanitize_color( $input['primary_color'] ?? $defaults['primary_color'], $defaults['primary_color'] );
			$output['hover_color'] = $this->sanitize_color( $input['hover_color'] ?? $defaults['hover_color'], $defaults['hover_color'] );
			$output['icon_color'] = $this->sanitize_color( $input['icon_color'] ?? $defaults['icon_color'], $defaults['icon_color'] );
			$output['text_color'] = $this->sanitize_color( $input['text_color'] ?? $defaults['text_color'], $defaults['text_color'] );
			$output['panel_color'] = $this->sanitize_color( $input['panel_color'] ?? $defaults['panel_color'], $defaults['panel_color'] );
			$output['panel_text_color'] = $this->sanitize_color( $input['panel_text_color'] ?? $defaults['panel_text_color'], $defaults['panel_text_color'] );
			$output['badge_color'] = $this->sanitize_color( $input['badge_color'] ?? $defaults['badge_color'], $defaults['badge_color'] );
			$output['badge_text'] = sanitize_text_field( $input['badge_text'] ?? $defaults['badge_text'] );
			$output['show_badge'] = empty( $input['show_badge'] ) ? 0 : 1;
			$output['z_index'] = max( 1, absint( $input['z_index'] ?? $defaults['z_index'] ) );
			$output['offset_x'] = absint( $input['offset_x'] ?? $defaults['offset_x'] );
			$output['offset_y'] = absint( $input['offset_y'] ?? $defaults['offset_y'] );
			$output['open_delay'] = absint( $input['open_delay'] ?? $defaults['open_delay'] );
			$output['auto_open'] = empty( $input['auto_open'] ) ? 0 : 1;
			$output['allow_mobile'] = empty( $input['allow_mobile'] ) ? 0 : 1;
			$output['allow_desktop'] = empty( $input['allow_desktop'] ) ? 0 : 1;
			$output['link_target'] = $this->sanitize_choice( $input['link_target'] ?? $defaults['link_target'], array( '_blank', '_self' ), $defaults['link_target'] );
			$output['display_rules'] = $this->sanitize_choice( $input['display_rules'] ?? $defaults['display_rules'], array( 'all', 'front_page', 'singular', 'selected_post_types' ), $defaults['display_rules'] );
			$output['include_post_types'] = $this->sanitize_post_types( $input['include_post_types'] ?? array() );
			$output['include_ids'] = $this->sanitize_id_list( $input['include_ids'] ?? '' );
			$output['exclude_ids'] = $this->sanitize_id_list( $input['exclude_ids'] ?? '' );
			$output['schedule_enabled'] = empty( $input['schedule_enabled'] ) ? 0 : 1;
			$output['schedule_days'] = $this->sanitize_days( $input['schedule_days'] ?? array() );
			$output['schedule_start'] = $this->sanitize_time( $input['schedule_start'] ?? $defaults['schedule_start'], $defaults['schedule_start'] );
			$output['schedule_end'] = $this->sanitize_time( $input['schedule_end'] ?? $defaults['schedule_end'], $defaults['schedule_end'] );
			$output['online_label'] = sanitize_text_field( $input['online_label'] ?? $defaults['online_label'] );
			$output['offline_label'] = sanitize_text_field( $input['offline_label'] ?? $defaults['offline_label'] );
			$output['offline_message'] = sanitize_textarea_field( $input['offline_message'] ?? $defaults['offline_message'] );
			$output['custom_css'] = sanitize_textarea_field( $input['custom_css'] ?? '' );
			$output['contacts'] = $this->sanitize_contacts( $input['contacts'] ?? array(), $defaults['contacts'] );

			return $output;
		}

		private function sanitize_choice( $value, $allowed, $default ) {
			$value = sanitize_key( $value );

			if ( in_array( $value, $allowed, true ) ) {
				return $value;
			}

			return $default;
		}

		private function sanitize_color( $value, $default ) {
			$color = sanitize_hex_color( $value );

			return $color ? $color : $default;
		}

		private function sanitize_post_types( $value ) {
			$allowed = array_keys( get_post_types( array( 'public' => true, 'show_ui' => true ), 'objects' ) );
			$values  = is_array( $value ) ? $value : array();
			$result  = array();

			foreach ( $values as $post_type ) {
				$post_type = sanitize_key( $post_type );
				if ( in_array( $post_type, $allowed, true ) ) {
					$result[] = $post_type;
				}
			}

			if ( empty( $result ) ) {
				$result = array( 'post', 'page' );
			}

			return array_values( array_unique( $result ) );
		}

		private function sanitize_id_list( $value ) {
			if ( is_array( $value ) ) {
				$value = implode( ',', $value );
			}

			$ids = preg_split( '/[\s,]+/', (string) $value );
			$ids = array_filter(
				array_map(
					'absint',
					array_map( 'trim', $ids )
				)
			);

			return implode( ', ', $ids );
		}

		private function sanitize_days( $value ) {
			$allowed = array( 'mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun' );
			$value   = is_array( $value ) ? $value : array();
			$result  = array();

			foreach ( $value as $day ) {
				$day = sanitize_key( $day );
				if ( in_array( $day, $allowed, true ) ) {
					$result[] = $day;
				}
			}

			if ( empty( $result ) ) {
				$result = array( 'mon', 'tue', 'wed', 'thu', 'fri' );
			}

			return array_values( array_unique( $result ) );
		}

		private function sanitize_time( $value, $default ) {
			$value = sanitize_text_field( (string) $value );

			if ( preg_match( '/^([01]\d|2[0-3]):[0-5]\d$/', $value ) ) {
				return $value;
			}

			return $default;
		}

		private function sanitize_contacts( $contacts, $default_contacts ) {
			$contacts = is_array( $contacts ) ? $contacts : array();
			$output   = array();

			foreach ( $contacts as $contact ) {
				$contact = is_array( $contact ) ? $contact : array();
				$name    = sanitize_text_field( $contact['name'] ?? '' );
				$phone   = $this->normalize_phone( $contact['phone'] ?? '' );

				if ( '' === $name && '' === $phone ) {
					continue;
				}

				$output[] = array(
					'enabled'  => empty( $contact['enabled'] ) ? 0 : 1,
					'name'     => $name,
					'phone'    => $phone,
					'subtitle' => sanitize_text_field( $contact['subtitle'] ?? '' ),
					'message'  => sanitize_textarea_field( $contact['message'] ?? '' ),
					'avatar'   => esc_url_raw( $contact['avatar'] ?? '' ),
					'color'    => $this->sanitize_color( $contact['color'] ?? '', '#25D366' ),
				);
			}

			if ( empty( $output ) ) {
				$output = $default_contacts;
			}

			return $output;
		}

		private function normalize_phone( $phone ) {
			$phone = preg_replace( '/[^0-9+]/', '', (string) $phone );
			$phone = ltrim( $phone, '+' );

			return $phone;
		}

		private function field_name( $key ) {
			return self::OPTION_NAME . '[' . $key . ']';
		}

		private function field_id( $key ) {
			return 'wcme_' . preg_replace( '/[^a-z0-9_]+/i', '_', $key );
		}

		private function get_value( $settings, $key, $default = '' ) {
			return isset( $settings[ $key ] ) ? $settings[ $key ] : $default;
		}

		private function render_input_field( $settings, $key, $label, $args = array() ) {
			$type        = $args['type'] ?? 'text';
			$placeholder = $args['placeholder'] ?? '';
			$help        = $args['help'] ?? '';
			$class       = $args['class'] ?? 'regular-text';
			$min         = $args['min'] ?? '';
			$max         = $args['max'] ?? '';
			$step        = $args['step'] ?? '';
			$value       = $this->get_value( $settings, $key, '' );

			echo '<div class="wcme-field wcme-field--' . esc_attr( $type ) . '">';
			echo '<label for="' . esc_attr( $this->field_id( $key ) ) . '"><strong>' . esc_html( $label ) . '</strong></label>';
			echo '<input type="' . esc_attr( $type ) . '" id="' . esc_attr( $this->field_id( $key ) ) . '" name="' . esc_attr( $this->field_name( $key ) ) . '" value="' . esc_attr( $value ) . '" class="' . esc_attr( $class ) . '" placeholder="' . esc_attr( $placeholder ) . '"';

			if ( '' !== $min ) {
				echo ' min="' . esc_attr( $min ) . '"';
			}

			if ( '' !== $max ) {
				echo ' max="' . esc_attr( $max ) . '"';
			}

			if ( '' !== $step ) {
				echo ' step="' . esc_attr( $step ) . '"';
			}

			echo ' />';

			if ( '' !== $help ) {
				echo '<p class="description">' . wp_kses_post( $help ) . '</p>';
			}

			echo '</div>';
		}

		private function render_textarea_field( $settings, $key, $label, $args = array() ) {
			$help  = $args['help'] ?? '';
			$rows  = $args['rows'] ?? 4;
			$class = $args['class'] ?? 'large-text';
			$value = $this->get_value( $settings, $key, '' );

			echo '<div class="wcme-field wcme-field--textarea">';
			echo '<label for="' . esc_attr( $this->field_id( $key ) ) . '"><strong>' . esc_html( $label ) . '</strong></label>';
			echo '<textarea id="' . esc_attr( $this->field_id( $key ) ) . '" name="' . esc_attr( $this->field_name( $key ) ) . '" rows="' . esc_attr( $rows ) . '" class="' . esc_attr( $class ) . '">' . esc_textarea( $value ) . '</textarea>';

			if ( '' !== $help ) {
				echo '<p class="description">' . wp_kses_post( $help ) . '</p>';
			}

			echo '</div>';
		}

		private function render_select_field( $settings, $key, $label, $options, $args = array() ) {
			$help  = $args['help'] ?? '';
			$class = $args['class'] ?? 'regular-text';
			$value = $this->get_value( $settings, $key, '' );

			echo '<div class="wcme-field wcme-field--select">';
			echo '<label for="' . esc_attr( $this->field_id( $key ) ) . '"><strong>' . esc_html( $label ) . '</strong></label>';
			echo '<select id="' . esc_attr( $this->field_id( $key ) ) . '" name="' . esc_attr( $this->field_name( $key ) ) . '" class="' . esc_attr( $class ) . '">';
			foreach ( $options as $option_value => $option_label ) {
				echo '<option value="' . esc_attr( $option_value ) . '" ' . selected( (string) $value, (string) $option_value, false ) . '>' . esc_html( $option_label ) . '</option>';
			}
			echo '</select>';

			if ( '' !== $help ) {
				echo '<p class="description">' . wp_kses_post( $help ) . '</p>';
			}

			echo '</div>';
		}

		private function render_checkbox_field( $settings, $key, $label, $args = array() ) {
			$help  = $args['help'] ?? '';
			$value = ! empty( $settings[ $key ] );

			echo '<div class="wcme-field wcme-field--checkbox">';
			echo '<label class="wcme-checkbox" for="' . esc_attr( $this->field_id( $key ) ) . '">';
			echo '<input type="checkbox" id="' . esc_attr( $this->field_id( $key ) ) . '" name="' . esc_attr( $this->field_name( $key ) ) . '" value="1" ' . checked( $value, true, false ) . ' />';
			echo '<span>' . esc_html( $label ) . '</span>';
			echo '</label>';

			if ( '' !== $help ) {
				echo '<p class="description">' . wp_kses_post( $help ) . '</p>';
			}

			echo '</div>';
		}

		private function render_multicheck_field( $settings, $key, $label, $options, $args = array() ) {
			$help    = $args['help'] ?? '';
			$checked = isset( $settings[ $key ] ) && is_array( $settings[ $key ] ) ? $settings[ $key ] : array();

			echo '<div class="wcme-field wcme-field--multicheck">';
			echo '<strong>' . esc_html( $label ) . '</strong>';
			echo '<div class="wcme-checklist">';
			foreach ( $options as $option_value => $option_label ) {
				$field_name = self::OPTION_NAME . '[' . $key . '][]';
				$field_id   = $this->field_id( $key . '_' . $option_value );
				echo '<label class="wcme-checkbox" for="' . esc_attr( $field_id ) . '">';
				echo '<input type="checkbox" id="' . esc_attr( $field_id ) . '" name="' . esc_attr( $field_name ) . '" value="' . esc_attr( $option_value ) . '" ' . checked( in_array( (string) $option_value, $checked, true ), true, false ) . ' />';
				echo '<span>' . esc_html( $option_label ) . '</span>';
				echo '</label>';
			}
			echo '</div>';

			if ( '' !== $help ) {
				echo '<p class="description">' . wp_kses_post( $help ) . '</p>';
			}

			echo '</div>';
		}

		private function render_contact_row( $index, $contact ) {
			$name_prefix = self::OPTION_NAME . '[contacts][' . $index . ']';
			$checked     = ! empty( $contact['enabled'] );

			echo '<tr class="wcme-contact-row" data-wcme-contact-row data-wcme-contact-index="' . esc_attr( $index ) . '">';
			echo '<td class="wcme-contact-cell wcme-contact-cell--enabled"><label class="wcme-checkbox"><input type="checkbox" name="' . esc_attr( $name_prefix . '[enabled]' ) . '" value="1" ' . checked( $checked, true, false ) . ' /></label></td>';
			echo '<td class="wcme-contact-cell"><input type="text" class="regular-text" name="' . esc_attr( $name_prefix . '[name]' ) . '" value="' . esc_attr( $contact['name'] ?? '' ) . '" /></td>';
			echo '<td class="wcme-contact-cell"><input type="text" class="regular-text" name="' . esc_attr( $name_prefix . '[phone]' ) . '" value="' . esc_attr( $contact['phone'] ?? '' ) . '" placeholder="15551234567" /></td>';
			echo '<td class="wcme-contact-cell"><input type="text" class="regular-text" name="' . esc_attr( $name_prefix . '[subtitle]' ) . '" value="' . esc_attr( $contact['subtitle'] ?? '' ) . '" /></td>';
			echo '<td class="wcme-contact-cell"><textarea rows="3" class="large-text" name="' . esc_attr( $name_prefix . '[message]' ) . '">' . esc_textarea( $contact['message'] ?? '' ) . '</textarea></td>';
			echo '<td class="wcme-contact-cell"><input type="url" class="regular-text" name="' . esc_attr( $name_prefix . '[avatar]' ) . '" value="' . esc_attr( $contact['avatar'] ?? '' ) . '" placeholder="https://example.com/avatar.jpg" /></td>';
			echo '<td class="wcme-contact-cell wcme-contact-cell--color"><input type="text" class="wcme-color-field" name="' . esc_attr( $name_prefix . '[color]' ) . '" value="' . esc_attr( $contact['color'] ?? '#25D366' ) . '" /></td>';
			echo '<td class="wcme-contact-cell wcme-contact-cell--actions"><button type="button" class="button-link-delete" data-wcme-remove-contact>' . esc_html__( 'Remove', 'whatsapp-chat-made-easy' ) . '</button></td>';
			echo '</tr>';
		}

		private function render_contact_template() {
			echo '<template id="wcme-contact-template">';
			$this->render_contact_row( '__INDEX__', array( 'enabled' => 1, 'color' => '#25D366' ) );
			echo '</template>';
		}

		private function get_admin_preview_vars( $settings ) {
			return sprintf(
				'--wcme-primary:%1$s;--wcme-hover:%2$s;--wcme-icon:%3$s;--wcme-text:%4$s;--wcme-badge:%5$s;',
				esc_attr( $settings['primary_color'] ),
				esc_attr( $settings['hover_color'] ),
				esc_attr( $settings['icon_color'] ),
				esc_attr( $settings['text_color'] ),
				esc_attr( $settings['badge_color'] )
			);
		}

		private function render_admin_icon_preview( $settings ) {
			$icon_styles = array(
				'classic' => __( 'Classic', 'whatsapp-chat-made-easy' ),
				'bubble'  => __( 'Bubble', 'whatsapp-chat-made-easy' ),
				'outline' => __( 'Outline', 'whatsapp-chat-made-easy' ),
				'minimal' => __( 'Minimal', 'whatsapp-chat-made-easy' ),
				'solid'   => __( 'Solid', 'whatsapp-chat-made-easy' ),
				'neon'    => __( 'Neon', 'whatsapp-chat-made-easy' ),
			);
			$current_style = $settings['icon_style'] ?? 'classic';
			$source_label  = 'plugin_assets' === ( $settings['icon_source'] ?? 'plugin_assets' )
				? __( 'Showing plugin-bundled files from assets/icons/. Custom files with the same names appear here automatically.', 'whatsapp-chat-made-easy' )
				: __( 'Showing inline SVG icons. The icon, primary, and badge colors below affect these previews.', 'whatsapp-chat-made-easy' );

			echo '<section class="wcme-card wcme-preview" style="' . esc_attr( $this->get_admin_preview_vars( $settings ) ) . '">';
			echo '<div class="wcme-preview-content wcme-icon-preview-stack">';
			echo '<div class="wcme-icon-preview-current">';
			echo '<span class="wcme-preview-eyebrow">' . esc_html__( 'Current launcher', 'whatsapp-chat-made-easy' ) . '</span>';
			echo '<div class="wcme-button-demo wcme-button-demo--' . esc_attr( $settings['button_style'] ) . ' wcme-button-demo--' . esc_attr( $settings['shape'] ) . '">';
			echo $this->render_launcher_content( $settings );
			echo '</div>';
			echo '<p>' . esc_html( $source_label ) . '</p>';
			echo '</div>';

			echo '<div class="wcme-icon-preview-grid">';
			foreach ( $icon_styles as $style_key => $style_label ) {
				$preview_settings               = $settings;
				$preview_settings['icon_style'] = $style_key;
				$preview_settings['icon_type']  = 'icon_only';

				echo '<div class="wcme-icon-preview-item' . ( $style_key === $current_style ? ' is-active' : '' ) . '">';
				echo '<div class="wcme-icon-preview-surface">';
				echo $this->render_icon( $preview_settings );
				echo '</div>';
				echo '<div class="wcme-icon-preview-meta">';
				echo '<strong>' . esc_html( $style_label ) . '</strong>';
				if ( $style_key === $current_style ) {
					echo '<span class="wcme-icon-preview-chip">' . esc_html__( 'Selected', 'whatsapp-chat-made-easy' ) . '</span>';
				}
				echo '</div>';
				echo '</div>';
			}
			echo '</div>';
			echo '</div>';
			echo '</section>';
		}

		public function render_settings_page() {
			$settings = $this->get_settings();
			$public_post_types = get_post_types( array( 'public' => true, 'show_ui' => true ), 'objects' );
			$post_type_options = array();

			foreach ( $public_post_types as $post_type => $object ) {
				$post_type_options[ $post_type ] = $object->labels->singular_name;
			}

			echo '<div class="wrap wcme-settings">';
			echo '<div class="wcme-settings__hero">';
			echo '<h1>' . esc_html__( 'WhatsApp Chat Made Easy', 'whatsapp-chat-made-easy' ) . '</h1>';
			echo '<p>' . esc_html__( 'Build a flexible WhatsApp chat experience with floating launchers, multiple contacts, business hours, and shortcode or widget placement.', 'whatsapp-chat-made-easy' ) . '</p>';
			echo '<div class="wcme-settings__shortcode">' . esc_html__( 'Shortcode:', 'whatsapp-chat-made-easy' ) . ' <code>[wcme_whatsapp_chat]</code></div>';
			echo '</div>';

			settings_errors();

			echo '<form method="post" action="options.php">';
			settings_fields( 'wcme_settings_group' );

			echo '<div class="wcme-grid">';
			echo '<section class="wcme-card">';
			echo '<h2>' . esc_html__( 'General', 'whatsapp-chat-made-easy' ) . '</h2>';
			$this->render_checkbox_field( $settings, 'enabled', __( 'Enable global floating button', 'whatsapp-chat-made-easy' ), array( 'help' => __( 'Disable this if you only want to use the shortcode or widget.', 'whatsapp-chat-made-easy' ) ) );
			$this->render_input_field( $settings, 'button_label', __( 'Button label', 'whatsapp-chat-made-easy' ) );
			$this->render_input_field( $settings, 'headline', __( 'Panel headline', 'whatsapp-chat-made-easy' ) );
			$this->render_textarea_field( $settings, 'description', __( 'Panel description', 'whatsapp-chat-made-easy' ), array( 'rows' => 3 ) );
			$this->render_select_field( $settings, 'mode', __( 'Launcher mode', 'whatsapp-chat-made-easy' ), array( 'panel' => __( 'Floating panel', 'whatsapp-chat-made-easy' ), 'direct' => __( 'Direct WhatsApp link', 'whatsapp-chat-made-easy' ) ) );
			$this->render_select_field( $settings, 'link_target', __( 'Link target', 'whatsapp-chat-made-easy' ), array( '_blank' => __( 'Open in new tab', 'whatsapp-chat-made-easy' ), '_self' => __( 'Open in same tab', 'whatsapp-chat-made-easy' ) ) );
			$this->render_checkbox_field( $settings, 'show_badge', __( 'Show badge', 'whatsapp-chat-made-easy' ) );
			$this->render_input_field( $settings, 'badge_text', __( 'Badge text', 'whatsapp-chat-made-easy' ) );
			echo '</section>';

			echo '<section class="wcme-card">';
			echo '<h2>' . esc_html__( 'Appearance', 'whatsapp-chat-made-easy' ) . '</h2>';
			$this->render_select_field( $settings, 'position', __( 'Button position', 'whatsapp-chat-made-easy' ), array(
				'bottom-right' => __( 'Bottom right', 'whatsapp-chat-made-easy' ),
				'bottom-left'  => __( 'Bottom left', 'whatsapp-chat-made-easy' ),
				'top-right'    => __( 'Top right', 'whatsapp-chat-made-easy' ),
				'top-left'     => __( 'Top left', 'whatsapp-chat-made-easy' ),
				'middle-right' => __( 'Middle right', 'whatsapp-chat-made-easy' ),
				'middle-left'  => __( 'Middle left', 'whatsapp-chat-made-easy' ),
			) );
			$this->render_select_field( $settings, 'size', __( 'Button size', 'whatsapp-chat-made-easy' ), array(
				'small'  => __( 'Small', 'whatsapp-chat-made-easy' ),
				'medium' => __( 'Medium', 'whatsapp-chat-made-easy' ),
				'large'  => __( 'Large', 'whatsapp-chat-made-easy' ),
				'xlarge' => __( 'Extra large', 'whatsapp-chat-made-easy' ),
			) );
			$this->render_select_field( $settings, 'shape', __( 'Button shape', 'whatsapp-chat-made-easy' ), array(
				'circle'  => __( 'Circle', 'whatsapp-chat-made-easy' ),
				'rounded' => __( 'Rounded', 'whatsapp-chat-made-easy' ),
				'pill'    => __( 'Pill', 'whatsapp-chat-made-easy' ),
				'square'  => __( 'Square', 'whatsapp-chat-made-easy' ),
			) );
			$this->render_select_field( $settings, 'button_style', __( 'Button style', 'whatsapp-chat-made-easy' ), array(
				'classic' => __( 'Classic gradient', 'whatsapp-chat-made-easy' ),
				'glass'   => __( 'Glass', 'whatsapp-chat-made-easy' ),
				'outline' => __( 'Outline', 'whatsapp-chat-made-easy' ),
				'minimal' => __( 'Minimal', 'whatsapp-chat-made-easy' ),
				'solid'   => __( 'Solid', 'whatsapp-chat-made-easy' ),
				'neon'    => __( 'Neon glow', 'whatsapp-chat-made-easy' ),
			) );
			$this->render_select_field( $settings, 'icon_source', __( 'Icon source', 'whatsapp-chat-made-easy' ), array(
				'plugin_assets' => __( 'Plugin files in assets/icons/', 'whatsapp-chat-made-easy' ),
				'inline_svg'    => __( 'Inline SVG (uses color pickers)', 'whatsapp-chat-made-easy' ),
			), array( 'help' => __( 'Plugin files stay inside the plugin ZIP for WordPress.org packaging. Inline SVG keeps icon colors connected to the color pickers.', 'whatsapp-chat-made-easy' ) ) );
			$this->render_select_field( $settings, 'icon_style', __( 'Icon style', 'whatsapp-chat-made-easy' ), array(
				'classic' => __( 'Classic', 'whatsapp-chat-made-easy' ),
				'bubble'  => __( 'Bubble', 'whatsapp-chat-made-easy' ),
				'outline' => __( 'Outline', 'whatsapp-chat-made-easy' ),
				'minimal' => __( 'Minimal', 'whatsapp-chat-made-easy' ),
				'solid'   => __( 'Solid', 'whatsapp-chat-made-easy' ),
				'neon'    => __( 'Neon', 'whatsapp-chat-made-easy' ),
			), array( 'help' => __( 'To override a style with your own file, place classic.svg, bubble.svg, outline.svg, minimal.svg, solid.svg, or neon.svg in assets/icons/. PNG, WEBP, JPG, and JPEG also work.', 'whatsapp-chat-made-easy' ) ) );
			$this->render_select_field( $settings, 'icon_type', __( 'Icon display type', 'whatsapp-chat-made-easy' ), array(
				'icon_only'  => __( 'Icon only', 'whatsapp-chat-made-easy' ),
				'icon_badge' => __( 'Icon with badge', 'whatsapp-chat-made-easy' ),
				'icon_text'  => __( 'Icon with text', 'whatsapp-chat-made-easy' ),
			), array( 'help' => __( 'Choose how to display the icon on the button.', 'whatsapp-chat-made-easy' ) ) );
			echo '<p class="wcme-form-help">';
			echo esc_html__( 'Recommended icon specs: use square SVG files when possible, with a 64x64 or 128x128 viewBox. PNG, WEBP, JPG, and JPEG should be 96x96 or 128x128 with a transparent background. Keep SVG files under 20 KB and raster files under 80 KB when possible.', 'whatsapp-chat-made-easy' );
			echo ' ';
			echo esc_html__( 'Store them in', 'whatsapp-chat-made-easy' ) . ' <code>assets/icons/</code> ' . esc_html__( 'inside this plugin.', 'whatsapp-chat-made-easy' );
			echo '</p>';
			$this->render_select_field( $settings, 'animation', __( 'Animation', 'whatsapp-chat-made-easy' ), array(
				'none'   => __( 'None', 'whatsapp-chat-made-easy' ),
				'pulse'  => __( 'Pulse', 'whatsapp-chat-made-easy' ),
				'float'  => __( 'Float', 'whatsapp-chat-made-easy' ),
				'bounce' => __( 'Bounce', 'whatsapp-chat-made-easy' ),
				'glow'   => __( 'Glow', 'whatsapp-chat-made-easy' ),
				'swing'  => __( 'Swing', 'whatsapp-chat-made-easy' ),
				'rotate' => __( 'Rotate', 'whatsapp-chat-made-easy' ),
				'scale'  => __( 'Scale', 'whatsapp-chat-made-easy' ),
				'wiggle' => __( 'Wiggle', 'whatsapp-chat-made-easy' ),
			) );
			$this->render_input_field( $settings, 'primary_color', __( 'Primary color', 'whatsapp-chat-made-easy' ), array( 'class' => 'wcme-color-field' ) );
			$this->render_input_field( $settings, 'hover_color', __( 'Hover color', 'whatsapp-chat-made-easy' ), array( 'class' => 'wcme-color-field' ) );
			$this->render_input_field( $settings, 'icon_color', __( 'Icon color', 'whatsapp-chat-made-easy' ), array( 'class' => 'wcme-color-field' ) );
			$this->render_input_field( $settings, 'text_color', __( 'Text color', 'whatsapp-chat-made-easy' ), array( 'class' => 'wcme-color-field' ) );
			$this->render_input_field( $settings, 'panel_color', __( 'Panel color', 'whatsapp-chat-made-easy' ), array( 'class' => 'wcme-color-field' ) );
			$this->render_input_field( $settings, 'panel_text_color', __( 'Panel text color', 'whatsapp-chat-made-easy' ), array( 'class' => 'wcme-color-field' ) );
			$this->render_input_field( $settings, 'badge_color', __( 'Badge color', 'whatsapp-chat-made-easy' ), array( 'class' => 'wcme-color-field' ) );
			$this->render_input_field( $settings, 'z_index', __( 'Z-index', 'whatsapp-chat-made-easy' ), array( 'type' => 'number', 'min' => 1, 'max' => 999999, 'step' => 1 ) );
			$this->render_input_field( $settings, 'offset_x', __( 'Horizontal offset (px)', 'whatsapp-chat-made-easy' ), array( 'type' => 'number', 'min' => 0, 'max' => 300, 'step' => 1 ) );
			$this->render_input_field( $settings, 'offset_y', __( 'Vertical offset (px)', 'whatsapp-chat-made-easy' ), array( 'type' => 'number', 'min' => 0, 'max' => 300, 'step' => 1 ) );
			echo '</section>';
			echo '</div>';

			$this->render_admin_icon_preview( $settings );

			echo '<div class="wcme-grid">';
			echo '<section class="wcme-card">';
			echo '<h2>' . esc_html__( 'Behavior', 'whatsapp-chat-made-easy' ) . '</h2>';
			$this->render_checkbox_field( $settings, 'allow_mobile', __( 'Show on mobile', 'whatsapp-chat-made-easy' ) );
			$this->render_checkbox_field( $settings, 'allow_desktop', __( 'Show on desktop', 'whatsapp-chat-made-easy' ) );
			$this->render_checkbox_field( $settings, 'auto_open', __( 'Auto open floating panel', 'whatsapp-chat-made-easy' ), array( 'help' => __( 'Only applies to the global floating panel mode.', 'whatsapp-chat-made-easy' ) ) );
			$this->render_input_field( $settings, 'open_delay', __( 'Auto open delay (ms)', 'whatsapp-chat-made-easy' ), array( 'type' => 'number', 'min' => 0, 'max' => 60000, 'step' => 50 ) );
			$this->render_checkbox_field( $settings, 'schedule_enabled', __( 'Enable business hours', 'whatsapp-chat-made-easy' ) );
			$this->render_multicheck_field( $settings, 'schedule_days', __( 'Open days', 'whatsapp-chat-made-easy' ), array(
				'mon' => __( 'Mon', 'whatsapp-chat-made-easy' ),
				'tue' => __( 'Tue', 'whatsapp-chat-made-easy' ),
				'wed' => __( 'Wed', 'whatsapp-chat-made-easy' ),
				'thu' => __( 'Thu', 'whatsapp-chat-made-easy' ),
				'fri' => __( 'Fri', 'whatsapp-chat-made-easy' ),
				'sat' => __( 'Sat', 'whatsapp-chat-made-easy' ),
				'sun' => __( 'Sun', 'whatsapp-chat-made-easy' ),
			) );
			$this->render_input_field( $settings, 'schedule_start', __( 'Open time', 'whatsapp-chat-made-easy' ), array( 'type' => 'time' ) );
			$this->render_input_field( $settings, 'schedule_end', __( 'Close time', 'whatsapp-chat-made-easy' ), array( 'type' => 'time' ) );
			$this->render_input_field( $settings, 'online_label', __( 'Online label', 'whatsapp-chat-made-easy' ) );
			$this->render_input_field( $settings, 'offline_label', __( 'Offline label', 'whatsapp-chat-made-easy' ) );
			$this->render_textarea_field( $settings, 'offline_message', __( 'Offline message', 'whatsapp-chat-made-easy' ), array( 'rows' => 3 ) );
			echo '</section>';

			echo '<section class="wcme-card">';
			echo '<h2>' . esc_html__( 'Display Rules', 'whatsapp-chat-made-easy' ) . '</h2>';
			$this->render_select_field( $settings, 'display_rules', __( 'Where to show', 'whatsapp-chat-made-easy' ), array(
				'all'                 => __( 'Everywhere', 'whatsapp-chat-made-easy' ),
				'front_page'          => __( 'Front page only', 'whatsapp-chat-made-easy' ),
				'singular'            => __( 'Single posts and pages', 'whatsapp-chat-made-easy' ),
				'selected_post_types'  => __( 'Selected post types', 'whatsapp-chat-made-easy' ),
			) );
			$this->render_multicheck_field( $settings, 'include_post_types', __( 'Allowed post types', 'whatsapp-chat-made-easy' ), $post_type_options, array( 'help' => __( 'Used when the display rule is set to selected post types.', 'whatsapp-chat-made-easy' ) ) );
			$this->render_input_field( $settings, 'include_ids', __( 'Only show on these IDs', 'whatsapp-chat-made-easy' ), array( 'placeholder' => '12, 34, 56' ) );
			$this->render_input_field( $settings, 'exclude_ids', __( 'Hide on these IDs', 'whatsapp-chat-made-easy' ), array( 'placeholder' => '7, 8, 9' ) );
			echo '</section>';
			echo '</div>';

			echo '<section class="wcme-card">';
			echo '<h2>' . esc_html__( 'Contacts', 'whatsapp-chat-made-easy' ) . '</h2>';
			echo '<p class="description">' . esc_html__( 'Add one or more WhatsApp agents. In direct mode the first enabled contact is used. In panel mode every enabled contact appears in the popup.', 'whatsapp-chat-made-easy' ) . '</p>';
			echo '<div class="wcme-table-wrap">';
			echo '<table class="widefat striped wcme-contacts-table" id="wcme-contacts-table">';
			echo '<thead><tr><th>' . esc_html__( 'On', 'whatsapp-chat-made-easy' ) . '</th><th>' . esc_html__( 'Name', 'whatsapp-chat-made-easy' ) . '</th><th>' . esc_html__( 'Phone', 'whatsapp-chat-made-easy' ) . '</th><th>' . esc_html__( 'Subtitle', 'whatsapp-chat-made-easy' ) . '</th><th>' . esc_html__( 'Message', 'whatsapp-chat-made-easy' ) . '</th><th>' . esc_html__( 'Avatar URL', 'whatsapp-chat-made-easy' ) . '</th><th>' . esc_html__( 'Color', 'whatsapp-chat-made-easy' ) . '</th><th>' . esc_html__( 'Actions', 'whatsapp-chat-made-easy' ) . '</th></tr></thead>';
			echo '<tbody>';
			foreach ( $settings['contacts'] as $index => $contact ) {
				$this->render_contact_row( $index, $contact );
			}
			echo '</tbody>';
			echo '</table>';
			echo '</div>';
			echo '<p><button type="button" class="button button-secondary" data-wcme-add-contact>' . esc_html__( 'Add contact', 'whatsapp-chat-made-easy' ) . '</button></p>';
			$this->render_contact_template();
			echo '</section>';

			echo '<section class="wcme-card">';
			echo '<h2>' . esc_html__( 'Advanced', 'whatsapp-chat-made-easy' ) . '</h2>';
			$this->render_textarea_field( $settings, 'custom_css', __( 'Custom CSS', 'whatsapp-chat-made-easy' ), array( 'rows' => 6, 'help' => __( 'Use this for final touch-ups. It is printed on the frontend only.', 'whatsapp-chat-made-easy' ) ) );
			echo '<p class="description">' . esc_html__( 'Message placeholders: {site_name}, {site_url}, {current_url}, {page_title}.', 'whatsapp-chat-made-easy' ) . '</p>';
			echo '<p class="description">' . esc_html__( 'No external tracking or remote services are used by this plugin.', 'whatsapp-chat-made-easy' ) . '</p>';
			echo '</section>';

			submit_button( __( 'Save Settings', 'whatsapp-chat-made-easy' ) );
			echo '</form>';
			echo '</div>';
		}

		public function shortcode( $atts ) {
			$atts = shortcode_atts(
				array(
					'phone'            => '',
					'message'          => '',
					'label'            => '',
					'headline'         => '',
					'description'      => '',
					'mode'             => '',
					'position'         => '',
					'size'             => '',
					'shape'            => '',
					'button_style'     => '',
					'icon_style'       => '',
					'icon_source'      => '',
					'primary_color'    => '',
					'hover_color'      => '',
					'icon_color'       => '',
					'text_color'       => '',
					'panel_color'      => '',
					'panel_text_color' => '',
					'badge_color'      => '',
					'badge_text'       => '',
					'show_badge'       => '',
					'open_delay'       => '',
					'auto_open'        => '',
					'class'            => '',
					'target'           => '',
				),
				$atts,
				'wcme_whatsapp_chat'
			);

			$overrides = array();

			foreach ( array( 'label' => 'button_label', 'headline' => 'headline', 'description' => 'description', 'mode' => 'mode', 'position' => 'position', 'size' => 'size', 'shape' => 'shape', 'button_style' => 'button_style', 'icon_style' => 'icon_style', 'icon_source' => 'icon_source', 'primary_color' => 'primary_color', 'hover_color' => 'hover_color', 'icon_color' => 'icon_color', 'text_color' => 'text_color', 'panel_color' => 'panel_color', 'panel_text_color' => 'panel_text_color', 'badge_color' => 'badge_color', 'badge_text' => 'badge_text', 'open_delay' => 'open_delay', 'target' => 'link_target' ) as $shortcode_key => $setting_key ) {
				if ( '' !== $atts[ $shortcode_key ] ) {
					$overrides[ $setting_key ] = $atts[ $shortcode_key ];
				}
			}

			if ( '' !== $atts['show_badge'] ) {
				$overrides['show_badge'] = (int) filter_var( $atts['show_badge'], FILTER_VALIDATE_BOOLEAN );
			}

			if ( '' !== $atts['auto_open'] ) {
				$overrides['auto_open'] = (int) filter_var( $atts['auto_open'], FILTER_VALIDATE_BOOLEAN );
			}

			if ( '' !== $atts['class'] ) {
				$overrides['extra_class'] = $atts['class'];
			}

			if ( '' !== $atts['phone'] ) {
				$overrides['contacts'] = array(
					array(
						'enabled'  => 1,
						'name'     => $atts['label'] ? $atts['label'] : __( 'WhatsApp', 'whatsapp-chat-made-easy' ),
						'phone'    => $atts['phone'],
						'subtitle' => '',
						'message'  => $atts['message'],
						'avatar'   => '',
						'color'    => '#25D366',
					),
				);
			}

			return $this->render_markup( $overrides, 'manual' );
		}

		public function render_global_button() {
			echo $this->render_markup( array(), 'global' );
		}

		private function should_render_global( $settings ) {
			if ( empty( $settings['enabled'] ) ) {
				return false;
			}

			if ( ! $this->device_allowed( $settings ) ) {
				return false;
			}

			if ( ! $this->schedule_allowed( $settings ) ) {
				return false;
			}

			if ( ! $this->display_rules_allowed( $settings ) ) {
				return false;
			}

			return true;
		}

		private function device_allowed( $settings ) {
			if ( wp_is_mobile() && empty( $settings['allow_mobile'] ) ) {
				return false;
			}

			if ( ! wp_is_mobile() && empty( $settings['allow_desktop'] ) ) {
				return false;
			}

			return true;
		}

		private function schedule_allowed( $settings ) {
			if ( empty( $settings['schedule_enabled'] ) ) {
				return true;
			}

			$timezone = function_exists( 'wp_timezone' ) ? wp_timezone() : new DateTimeZone( 'UTC' );
			$now      = current_datetime();
			$now      = new DateTimeImmutable( $now->format( 'Y-m-d H:i:s' ), $timezone );
			$current_day = strtolower( substr( $now->format( 'D' ), 0, 3 ) );

			if ( ! in_array( $current_day, $settings['schedule_days'], true ) ) {
				return false;
			}

			list( $start_hour, $start_minute ) = array_map( 'intval', explode( ':', $settings['schedule_start'] ) );
			list( $end_hour, $end_minute )     = array_map( 'intval', explode( ':', $settings['schedule_end'] ) );

			$start = $now->setTime( $start_hour, $start_minute );
			$end   = $now->setTime( $end_hour, $end_minute );

			if ( $start <= $end ) {
				return ( $now >= $start && $now <= $end );
			}

			return ( $now >= $start || $now <= $end );
		}

		private function display_rules_allowed( $settings ) {
			$current_id = get_queried_object_id();
			$include_ids = $this->parse_id_list( $settings['include_ids'] ?? '' );
			$exclude_ids = $this->parse_id_list( $settings['exclude_ids'] ?? '' );

			if ( $current_id && in_array( $current_id, $exclude_ids, true ) ) {
				return false;
			}

			if ( ! empty( $include_ids ) && ( ! $current_id || ! in_array( $current_id, $include_ids, true ) ) ) {
				return false;
			}

			switch ( $settings['display_rules'] ) {
				case 'front_page':
					return is_front_page();
				case 'singular':
					return is_singular();
				case 'selected_post_types':
					$types = ! empty( $settings['include_post_types'] ) && is_array( $settings['include_post_types'] ) ? $settings['include_post_types'] : array( 'post', 'page' );
					return is_singular( $types );
				default:
					return true;
			}
		}

		private function parse_id_list( $value ) {
			if ( is_array( $value ) ) {
				$value = implode( ',', $value );
			}

			$ids = preg_split( '/[\s,]+/', (string) $value );
			$ids = array_filter( array_map( 'absint', array_map( 'trim', $ids ) ) );

			return array_values( array_unique( $ids ) );
		}

		private function get_styles( $settings ) {
			$delay = absint( $settings['open_delay'] ) / 1000;

			return sprintf(
				'--wcme-primary:%1$s;--wcme-hover:%2$s;--wcme-icon:%3$s;--wcme-text:%4$s;--wcme-panel:%5$s;--wcme-panel-text:%6$s;--wcme-badge:%7$s;--wcme-z:%8$d;--wcme-offset-x:%9$dpx;--wcme-offset-y:%10$dpx;--wcme-delay:%11$.3fs;',
				esc_attr( $settings['primary_color'] ),
				esc_attr( $settings['hover_color'] ),
				esc_attr( $settings['icon_color'] ),
				esc_attr( $settings['text_color'] ),
				esc_attr( $settings['panel_color'] ),
				esc_attr( $settings['panel_text_color'] ),
				esc_attr( $settings['badge_color'] ),
				absint( $settings['z_index'] ),
				absint( $settings['offset_x'] ),
				absint( $settings['offset_y'] ),
				$delay
			);
		}

		public function render_markup( $overrides = array(), $context = 'global' ) {
			$settings = $this->get_settings( $overrides );
			$manual   = 'global' !== $context;

			if ( $manual ) {
				if ( ! $this->device_allowed( $settings ) || ! $this->schedule_allowed( $settings ) ) {
					return '';
				}
			} elseif ( ! $this->should_render_global( $settings ) ) {
				return '';
			}

			$contacts = $this->prepare_contacts( $settings );
			if ( empty( $contacts ) ) {
				return '';
			}

			$is_online = $this->schedule_allowed( $settings );
			$classes   = array(
				'wcme-chat',
				'wcme-chat--context-' . $context,
				'wcme-chat--position-' . $settings['position'],
				'wcme-chat--size-' . $settings['size'],
				'wcme-chat--shape-' . $settings['shape'],
				'wcme-chat--button-' . $settings['button_style'],
				'wcme-chat--icon-' . $settings['icon_style'],
				'wcme-chat--animation-' . $settings['animation'],
				'wcme-chat--mode-' . $settings['mode'],
			);

			if ( ! empty( $settings['allow_mobile'] ) && empty( $settings['allow_desktop'] ) ) {
				$classes[] = 'wcme-chat--hide-desktop';
			}

			if ( ! empty( $settings['allow_desktop'] ) && empty( $settings['allow_mobile'] ) ) {
				$classes[] = 'wcme-chat--hide-mobile';
			}

			if ( ! $is_online ) {
				$classes[] = 'wcme-chat--offline';
			}

			if ( $manual ) {
				$classes[] = 'wcme-chat--inline';
			}

			if ( ! empty( $settings['extra_class'] ) ) {
				$extra_classes = preg_split( '/\s+/', (string) $settings['extra_class'] );
				foreach ( $extra_classes as $extra_class ) {
					$extra_class = sanitize_html_class( $extra_class );
					if ( '' !== $extra_class ) {
						$classes[] = $extra_class;
					}
				}
			}

			$panel_id         = wp_unique_id( 'wcme-panel-' );
			$styles           = $this->get_styles( $settings );
			$primary_contact   = $contacts[0];
			$panel_title       = $is_online ? $settings['headline'] : $settings['offline_label'];
			$panel_description = $is_online ? $settings['description'] : $settings['offline_message'];

			ob_start();
			?>
			<div class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>" style="<?php echo esc_attr( $styles ); ?>" data-wcme-auto-open="<?php echo esc_attr( ! empty( $settings['auto_open'] ) ? 1 : 0 ); ?>" data-wcme-delay="<?php echo esc_attr( absint( $settings['open_delay'] ) ); ?>">
				<?php if ( 'direct' === $settings['mode'] ) : ?>
					<a class="wcme-launcher wcme-launcher--link" href="<?php echo esc_url( $this->build_whatsapp_url( $primary_contact, $settings ) ); ?>" target="<?php echo esc_attr( $settings['link_target'] ); ?>" rel="noopener noreferrer" aria-label="<?php echo esc_attr( $settings['button_label'] ); ?>">
						<?php echo $this->render_launcher_content( $settings ); ?>
					</a>
				<?php else : ?>
					<?php if ( $manual ) : ?>
						<div class="wcme-launcher wcme-launcher--static" aria-hidden="true">
							<?php echo $this->render_launcher_content( $settings ); ?>
						</div>
					<?php else : ?>
						<button type="button" class="wcme-launcher" data-wcme-toggle aria-controls="<?php echo esc_attr( $panel_id ); ?>" aria-expanded="false">
							<?php echo $this->render_launcher_content( $settings ); ?>
						</button>
					<?php endif; ?>

					<div class="wcme-panel" id="<?php echo esc_attr( $panel_id ); ?>" aria-live="polite">
						<div class="wcme-panel__header">
							<div class="wcme-panel__header-copy">
								<p class="wcme-panel__eyebrow"><?php echo esc_html( $is_online ? $settings['online_label'] : $settings['offline_label'] ); ?></p>
								<h3><?php echo esc_html( $panel_title ); ?></h3>
								<p><?php echo esc_html( $panel_description ); ?></p>
							</div>
							<span class="wcme-panel__status <?php echo esc_attr( $is_online ? 'is-online' : 'is-offline' ); ?>">
								<span class="wcme-panel__dot"></span>
								<?php echo esc_html( $is_online ? $settings['online_label'] : $settings['offline_label'] ); ?>
							</span>
						</div>
						<div class="wcme-panel__body">
							<?php foreach ( $contacts as $contact ) : ?>
								<?php echo $this->render_contact_card( $contact, $settings ); ?>
							<?php endforeach; ?>
						</div>
						<div class="wcme-panel__footer"><?php echo esc_html( $panel_description ); ?></div>
					</div>
				<?php endif; ?>
			</div>
			<?php

			return ob_get_clean();
		}

		private function prepare_contacts( $settings ) {
			$prepared = array();

			foreach ( (array) $settings['contacts'] as $contact ) {
				$contact = is_array( $contact ) ? $contact : array();
				if ( empty( $contact['enabled'] ) ) {
					continue;
				}

				$phone = $this->normalize_phone( $contact['phone'] ?? '' );
				if ( '' === $phone ) {
					continue;
				}

				$name = sanitize_text_field( $contact['name'] ?? '' );
				if ( '' === $name ) {
					$name = __( 'WhatsApp contact', 'whatsapp-chat-made-easy' );
				}

				$message = sanitize_textarea_field( $contact['message'] ?? '' );
				if ( '' === $message ) {
					$message = $settings['description'];
				}

				$prepared[] = array(
					'name'     => $name,
					'phone'    => $phone,
					'subtitle' => sanitize_text_field( $contact['subtitle'] ?? '' ),
					'message'  => $this->apply_placeholders( $message ),
					'avatar'   => esc_url_raw( $contact['avatar'] ?? '' ),
					'color'    => $this->sanitize_color( $contact['color'] ?? '', '#25D366' ),
					'initials' => $this->get_initials( $name ),
					'chat_url' => $this->build_whatsapp_url( array( 'phone' => $phone, 'message' => $message ), $settings ),
				);
			}

			if ( empty( $prepared ) ) {
				$defaults = self::defaults()['contacts'];
				foreach ( $defaults as $contact ) {
					$message = $this->apply_placeholders( $contact['message'] );
					$prepared[] = array(
						'name'     => $contact['name'],
						'phone'    => $this->normalize_phone( $contact['phone'] ),
						'subtitle' => $contact['subtitle'],
						'message'  => $message,
						'avatar'   => '',
						'color'    => $contact['color'],
						'initials' => $this->get_initials( $contact['name'] ),
						'chat_url' => $this->build_whatsapp_url( array( 'phone' => $contact['phone'], 'message' => $message ), $settings ),
					);
				}
			}

			return $prepared;
		}

		private function build_whatsapp_url( $contact, $settings ) {
			$phone = $this->normalize_phone( $contact['phone'] ?? '' );
			if ( '' === $phone ) {
				return '#';
			}

			$message = $contact['message'] ?? '';
			if ( '' === $message ) {
				$message = $settings['description'];
			}

			$message = $this->apply_placeholders( $message );

			if ( '' === $message ) {
				return 'https://wa.me/' . rawurlencode( $phone );
			}

			return 'https://wa.me/' . rawurlencode( $phone ) . '?text=' . rawurlencode( $message );
		}

		private function apply_placeholders( $message ) {
			$page_title = is_singular() ? get_the_title( get_queried_object_id() ) : wp_get_document_title();
			$replacements = array(
				'{site_name}'   => get_bloginfo( 'name' ),
				'{site_url}'    => home_url( '/' ),
				'{current_url}' => $this->current_url(),
				'{page_title}'  => $page_title,
			);

			return strtr( (string) $message, $replacements );
		}

		private function current_url() {
			$scheme = is_ssl() ? 'https://' : 'http://';
			$host   = isset( $_SERVER['HTTP_HOST'] ) ? wp_unslash( $_SERVER['HTTP_HOST'] ) : '';
			$path   = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/';

			return esc_url_raw( $scheme . $host . $path );
		}

		private function get_initials( $name ) {
			$name   = trim( (string) $name );
			$parts  = preg_split( '/\s+/', $name );
			$result = '';

			foreach ( $parts as $part ) {
				$part = trim( $part );
				if ( '' === $part ) {
					continue;
				}

				if ( function_exists( 'mb_substr' ) ) {
					$result .= mb_substr( $part, 0, 1 );
				} else {
					$result .= substr( $part, 0, 1 );
				}

				if ( strlen( $result ) >= 2 ) {
					break;
				}
			}

			$result = strtoupper( $result );

			return '' !== $result ? $result : 'W';
		}

		private function render_launcher_content( $settings ) {
			$show_label = 'icon_only' !== ( $settings['icon_type'] ?? 'icon_only' );
			
			ob_start();
			?>
			<?php echo $this->render_icon( $settings ); ?>
			<?php if ( $show_label ) : ?>
				<span class="wcme-launcher__label"><?php echo esc_html( $settings['button_label'] ); ?></span>
			<?php endif; ?>
			<?php echo $this->render_badge( $settings ); ?>
			<?php
			return ob_get_clean();
		}

		private function render_icon( $settings ) {
			$style = isset( $settings['icon_style'] ) ? $settings['icon_style'] : 'classic';
			$source = isset( $settings['icon_source'] ) ? $settings['icon_source'] : 'plugin_assets';
			$custom_icon_url = $this->get_icon_asset_url( $style );

			if ( 'plugin_assets' === $source && '' !== $custom_icon_url ) {
				return '<span class="wcme-icon wcme-icon--' . esc_attr( $style ) . ' wcme-icon--asset" aria-hidden="true"><img class="wcme-icon__image" src="' . esc_url( $custom_icon_url ) . '" alt="" decoding="async"/></span>';
			}

			$wa = 'M19.97 4.03A10 10 0 0 0 3.16 16.82L2 22l5.35-1.4A10 10 0 1 0 19.97 4.03z'
			    . 'm-7.82 13.04c-1.25 0-2.5-.33-3.6-.93l-.26-.14-2.9.76.77-2.82-.16-.26A7.28 7.28 0 1 1 12.15 17.07z'
			    . 'm4.24-4.92c-.22.63-1.3 1.2-1.77 1.27-.47.05-1.04.07-1.67-.12-.38-.12-.88-.28-1.51-.56'
			    . '-2.68-1.16-4.43-3.84-4.56-4.02-.13-.18-1.09-1.46-1.09-2.78 0-1.32.7-1.97.95-2.24'
			    . '.25-.28.55-.35.73-.35h.53c.16 0 .38-.07.59.45.22.53.76 1.84.82 1.97.07.13.1.29.02.48'
			    . '-.08.18-.12.3-.24.46-.13.16-.27.34-.39.45-.13.13-.27.28-.11.56.16.28.7 1.2 1.5 1.96'
			    . ' 1.04.97 1.93 1.27 2.2 1.41.28.13.44.11.59-.07.16-.18.67-.8.85-1.08.18-.28.36-.23'
			    . '.6-.14.24.09 1.55.76 1.82.89.27.13.44.2.5.31.06.1.06.68-.15 1.3z';

			$open = '<span class="wcme-icon wcme-icon--' . esc_attr( $style ) . '" aria-hidden="true">'
			      . '<svg class="wcme-icon__svg" viewBox="0 0 24 24" focusable="false" aria-hidden="true">';
			$end  = '</svg></span>';

			switch ( $style ) {
				case 'bubble':
					return $open
					     . '<rect x="1.5" y="1.5" width="21" height="21" rx="7.5" fill="var(--wcme-primary)"/>'
					     . '<path d="' . $wa . '" fill="#ffffff" fill-rule="evenodd"/>'
					     . $end;

				case 'outline':
					return $open
					     . '<circle cx="12" cy="12" r="10" fill="rgba(255,255,255,0.08)" stroke="currentColor" stroke-width="1.4"/>'
					     . '<path d="' . $wa . '" fill="currentColor" fill-rule="evenodd"/>'
					     . $end;

				case 'minimal':
					return $open
					     . '<path d="' . $wa . '" fill="currentColor" fill-rule="evenodd"/>'
					     . $end;

				case 'solid':
					return $open
					     . '<circle cx="12" cy="12" r="10.75" fill="var(--wcme-primary)"/>'
					     . '<path d="' . $wa . '" fill="#ffffff" fill-rule="evenodd"/>'
					     . $end;

				case 'neon':
					return $open
					     . '<circle cx="12" cy="12" r="10.75" fill="#081c10"/>'
					     . '<circle cx="12" cy="12" r="10" fill="none" stroke="rgba(37,211,102,0.42)" stroke-width="1.35"/>'
					     . '<path d="' . $wa . '" fill="#ffffff" fill-rule="evenodd"/>'
					     . $end;

				case 'classic':
				default:
					return $open
					     . '<circle cx="12" cy="12" r="10.75" fill="#ffffff"/>'
					     . '<path d="' . $wa . '" fill="currentColor" fill-rule="evenodd"/>'
					     . $end;
			}
		}

		private function get_icon_asset_url( $style ) {
			$style = preg_replace( '/[^a-z0-9_-]/i', '', (string) $style );

			if ( '' === $style ) {
				return '';
			}

			foreach ( array( 'svg', 'png', 'webp', 'jpg', 'jpeg' ) as $extension ) {
				$file_name = $style . '.' . $extension;
				$file_path = WCME_PATH . 'assets/icons/' . $file_name;

				if ( file_exists( $file_path ) ) {
					return WCME_URL . 'assets/icons/' . rawurlencode( $file_name );
				}
			}

			return '';
		}

		private function render_badge( $settings ) {
			if ( empty( $settings['show_badge'] ) || '' === trim( (string) $settings['badge_text'] ) ) {
				return '';
			}

			return '<span class="wcme-launcher__badge" aria-hidden="true">' . esc_html( $settings['badge_text'] ) . '</span>';
		}

		private function render_contact_card( $contact, $settings ) {
			$subtitle = '' !== trim( $contact['subtitle'] ) ? $contact['subtitle'] : $settings['button_label'];
			$message  = wp_trim_words( wp_strip_all_tags( $contact['message'] ), 18, '...' );

			ob_start();
			?>
			<a class="wcme-contact" href="<?php echo esc_url( $contact['chat_url'] ); ?>" target="<?php echo esc_attr( $settings['link_target'] ); ?>" rel="noopener noreferrer" style="--wcme-contact-accent: <?php echo esc_attr( $contact['color'] ); ?>;">
				<span class="wcme-contact__avatar">
					<?php if ( ! empty( $contact['avatar'] ) ) : ?>
						<img src="<?php echo esc_url( $contact['avatar'] ); ?>" alt="<?php echo esc_attr( $contact['name'] ); ?>" />
					<?php else : ?>
						<span class="wcme-contact__initials"><?php echo esc_html( $contact['initials'] ); ?></span>
					<?php endif; ?>
				</span>
				<span class="wcme-contact__copy">
					<strong><?php echo esc_html( $contact['name'] ); ?></strong>
					<span class="wcme-contact__subtitle"><?php echo esc_html( $subtitle ); ?></span>
					<span class="wcme-contact__message"><?php echo esc_html( $message ); ?></span>
				</span>
				<span class="wcme-contact__cta"><?php echo esc_html__( 'Chat', 'whatsapp-chat-made-easy' ); ?></span>
			</a>
			<?php

			return ob_get_clean();
		}
	}
}

if ( ! class_exists( 'WCME_Widget' ) ) {

	class WCME_Widget extends WP_Widget {

		public function __construct() {
			parent::__construct(
				'wcme_widget',
				__( 'WhatsApp Chat Made Easy', 'whatsapp-chat-made-easy' ),
				array(
					'description' => __( 'Display a WhatsApp chat box in widget areas.', 'whatsapp-chat-made-easy' ),
				)
			);
		}

		public function widget( $args, $instance ) {
			$title = ! empty( $instance['title'] ) ? $instance['title'] : '';

			echo $args['before_widget'];

			if ( $title ) {
				echo $args['before_title'] . esc_html( $title ) . $args['after_title'];
			}

			echo WCME_Plugin::instance()->render_markup( array(), 'manual' );

			echo $args['after_widget'];
		}

		public function form( $instance ) {
			$title = ! empty( $instance['title'] ) ? $instance['title'] : '';
			?>
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'whatsapp-chat-made-easy' ); ?></label>
				<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
			</p>
			<?php
		}

		public function update( $new_instance, $old_instance ) {
			$instance          = $old_instance;
			$instance['title'] = sanitize_text_field( $new_instance['title'] ?? '' );

			return $instance;
		}
	}
}
