<?php

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

delete_option( 'wcme_settings' );
delete_site_option( 'wcme_settings' );
