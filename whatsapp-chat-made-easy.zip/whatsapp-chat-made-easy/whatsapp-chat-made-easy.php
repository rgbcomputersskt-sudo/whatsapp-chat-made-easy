<?php
/**
 * Plugin Name: WhatsApp Chat Made Easy
 * Plugin URI: https://creativesoft.shop/
 * Description: Flexible WhatsApp chat plugin with floating buttons, multiple icon styles, 8+ animations, business hours, multi-contacts, widgets, shortcodes, and full customization.
 * Version: 1.1.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author: Creative Vision
 * Author URI: https://creativesoft.shop/
 * Text Domain: whatsapp-chat-made-easy
 * Domain Path: /languages
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'WCME_VERSION', '1.1.0' );
define( 'WCME_FILE', __FILE__ );
define( 'WCME_PATH', plugin_dir_path( __FILE__ ) );
define( 'WCME_URL', plugin_dir_url( __FILE__ ) );

require_once WCME_PATH . 'includes/class-wcme-plugin.php';

register_activation_hook( __FILE__, 'wcme_activate_plugin' );

function wcme_activate_plugin() {
	if ( false === get_option( WCME_Plugin::OPTION_NAME, false ) ) {
		add_option( WCME_Plugin::OPTION_NAME, WCME_Plugin::defaults() );
	}
}

add_action(
	'plugins_loaded',
	function () {
		WCME_Plugin::instance();
	}
);
