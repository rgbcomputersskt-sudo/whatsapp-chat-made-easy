=== WhatsApp Chat Made Easy ===
Contributors: creativevisionshop
Donate link: https://creativesoft.shop/donate
Tags: whatsapp, chat, floating button, contact, widget, shortcode, support, customer service, click to chat, responsive, messaging, live chat
Requires at least: 6.0
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Build a polished WhatsApp chat experience with floating buttons, multiple contacts, popup panels, business hours scheduling, widgets, shortcodes, and custom styling.

== Description ==

**WhatsApp Chat Made Easy** is the ultimate WordPress plugin for adding WhatsApp chat functionality to your website. Perfect for businesses that want to provide instant customer support, sales inquiries, or general contact via WhatsApp.

No coding required. No external API calls. No data collection. Just pure WhatsApp integration that works out of the box.

= Key Features =

**Flexible Display Options**
* Floating button that follows visitors as they scroll
* 6 corner positions (top/bottom-left/right, middle-left/right)
* Direct WhatsApp link mode or popup panel with multiple contacts
* Widget support for custom placement in sidebars and content areas
* Shortcode for embedding in pages and posts

**Stunning Design & Customization**
* 6 button styles: Classic, Glass, Outline, Minimal, Solid, Neon
* 6 unique icon styles with different visual treatments
* 3 icon display types: Icon only, Icon with badge, Icon with text
* Multiple button sizes (small, medium, large, extra-large)
* 4 shape options: Circle, Rounded, Pill, Square
* 8+ animations: Pulse, Float, Bounce, Glow, Swing, Rotate, Scale, Wiggle
* Full color customization for button, hover state, icon, text, and badge
* Glass morphism and neon glow effects

**Multi-Agent Support**
* Add unlimited WhatsApp contacts/team members
* Custom names, avatars, and subtitles for each contact
* Individual accent colors per contact
* Custom messages for each team member
* Avatar images or initials fallback

**Business Hours & Scheduling**
* Enable/disable based on day of week
* Set opening and closing times
* Custom online/offline labels and messages
* Timezone-aware scheduling
* Visitors see your availability status

**Smart Display Rules**
* Show/hide on specific pages
* Control visibility on front page, singular content, or specific post types
* Device-specific visibility (mobile and/or desktop)
* Auto-open functionality with customizable delay

**Developer-Friendly**
* RESTful shortcode system with attribute support
* Customizable CSS with inline style injection
* Mobile-responsive design
* WCAG 2.1 Level AA accessibility standards
* Clean, well-documented codebase
* No external dependencies or tracking

**Message Placeholders**
Personalize WhatsApp messages with dynamic content:
* {site_name} - Your website name
* {site_url} - Your website URL
* {current_url} - Current page URL
* {page_title} - Current page title

= Use Cases =

✓ Customer support teams
✓ E-commerce order support
✓ Sales inquiry funnels
✓ Appointment booking
✓ Service inquiries
✓ Technical support
✓ General contact information

== Installation ==

**Method 1: WordPress Dashboard**
1. Go to Plugins → Add New
2. Search for "WhatsApp Chat Made Easy"
3. Click Install Now and then Activate

**Method 2: Manual Upload**
1. Download the plugin ZIP file
2. Go to Plugins → Add New → Upload Plugin
3. Select the ZIP file and click Install Now
4. Activate the plugin

**First Steps**
1. Go to Settings → WhatsApp Chat
2. Add your WhatsApp number and contacts
3. Customize colors, size, and animations to match your brand
4. Enable the floating button or place it using shortcodes/widgets

== Frequently Asked Questions ==

= Do I need WhatsApp Business to use this? =
No. This works with any WhatsApp number. WhatsApp Business provides additional features like automated responses and analytics, but they're not required for this plugin.

= How many contacts can I add? =
Unlimited. Add as many team members as you need, each with their own number and custom message.

= Will this slow down my website? =
No. The plugin loads minimal CSS/JavaScript and has no external API dependencies. It uses vanilla JavaScript with no jQuery dependency.

= Can I use this without the floating button? =
Yes. Use the shortcode `[wcme_whatsapp_chat]` or add the widget to your sidebar. Disable the global floating button in settings.

= What's the difference between icon types? =
* **Icon only** - Just the WhatsApp icon, perfect for compact designs
* **Icon with badge** - Adds a notification badge for attention
* **Icon with text** - Shows label text next to the icon for clarity

= Can I customize the button appearance? =
Yes. Customize button style, icon style, size, shape, colors, animations, and more from the settings page.

= Can I use my own icon files? =
Yes. The plugin includes a `Plugin files in assets/icons/` icon source mode. Put your files in `assets/icons/` inside the plugin folder using the names `classic`, `bubble`, `outline`, `minimal`, `solid`, or `neon` with `.svg`, `.png`, `.webp`, `.jpg`, or `.jpeg` extensions.

= What icon size should I use? =
For the cleanest result, use square SVG files with a `64x64` or `128x128` viewBox. For PNG, WEBP, JPG, or JPEG, use `96x96` or `128x128`. Keep SVG files under `20 KB` and raster files under `80 KB` when possible.

= Are the custom icons stored inside the plugin? =
Yes, when you place them in `assets/icons/` they stay inside the plugin folder and ship with your plugin ZIP. This is the best approach if you want those icons to remain bundled when preparing a WordPress.org upload.

= Does this collect user data? =
No. This plugin stores only your WhatsApp numbers and preferences in the WordPress database. It doesn't track visitors or send any data externally.

= Will this work on mobile? =
Yes. Fully responsive design that works perfectly on all devices. You can control visibility separately for mobile and desktop.

= Can I set business hours? =
Yes. Enable the business hours feature in the Behavior section. Set your operating days and times, and the plugin will display different messages during business hours and offline.

= What are the different button styles? =
* **Classic** - Traditional gradient design
* **Glass** - Frosted glass effect
* **Outline** - Minimalist border-only style
* **Minimal** - Subtle with minimal styling
* **Solid** - Solid color background
* **Neon** - Vibrant neon glow effect

= Can I have multiple floating buttons? =
Yes. Use the shortcode with different parameters to create multiple buttons with different settings.

= Is this GDPR compliant? =
Yes. This plugin doesn't collect, store, or transmit any personal user data. It simply provides a link to WhatsApp.

== Screenshots ==

1. WhatsApp Chat Settings - Main configuration panel
2. Button Customization - Choose styles, sizes, shapes, and animations
3. Multi-Contact Setup - Add multiple team members with avatars
4. Business Hours - Set your availability schedule
5. Floating Button - Beautiful WhatsApp button on your website
6. Popup Panel - Displays all your contacts when visitors click
7. Mobile Responsive - Perfect appearance on all devices

== Support ==

For help and support, visit: https://creativesoft.shop/

Found a bug? Have a suggestion? We'd love to hear from you!

== Changelog ==

= 1.1.0 - July 2024 =
* Major UI/UX enhancements
* 6 new unique icon styles (Bubble, Outline, Minimal, Solid, Neon)
* 3 icon display types (Icon only, Icon with badge, Icon with text)
* 4 new animations (Swing, Rotate, Scale, Wiggle)
* Redesigned built-in icons and added bundled plugin icon files in assets/icons/
* Added icon source option for plugin files or inline SVG rendering
* Enhanced frontend CSS with improved animations
* Improved admin interface styling
* Better WordPress.org compliance
* Updated documentation and features

= 1.0.0 - June 2024 =
* Initial public release
* 6 button styles and 6 icon styles
* 8+ animation effects
* Multi-agent/contact support
* Business hours scheduling
* Device-specific visibility
* Display rules for page targeting
* Floating button, widget, and shortcode support
* Full color customization
* Responsive mobile design
* WCAG accessibility standards

== Upgrade Notice ==

= 1.1.0 =
Major UX/UX improvements! 6 new icon styles, 4 new animations, enhanced admin interface, and WordPress.org compliance updates. Fully backward compatible.

= 1.0.0 =
This is the initial public release of WhatsApp Chat Made Easy. No upgrades necessary.

== Credits ==

Built with ❤️ by Creative Vision Information Technology
Visit us: https://creativesoft.shop/

== License ==

This plugin is released under GPLv2 or later. See LICENSE file for details.

WhatsApp is a trademark of Meta Platforms, Inc. This plugin is not endorsed by or affiliated with WhatsApp/Meta.
