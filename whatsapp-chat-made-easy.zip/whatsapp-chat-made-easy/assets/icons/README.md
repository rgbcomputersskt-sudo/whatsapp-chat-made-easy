# Custom Icon Guide

Place your icon files in this folder to keep them inside the plugin package.

## Supported file names

- `classic.svg`
- `bubble.svg`
- `outline.svg`
- `minimal.svg`
- `solid.svg`
- `neon.svg`

The plugin also accepts `.png`, `.webp`, `.jpg`, and `.jpeg` using the same base names.

## Recommended specs

- Preferred format: SVG
- SVG size: square `64x64` or `128x128` viewBox
- Raster size: `96x96` or `128x128`
- Background: transparent for PNG/WEBP when possible
- Safe size target: SVG under `20 KB`, raster under `80 KB`

## Notes

- `Plugin files in assets/icons/` is the best option when you want the icons to stay bundled with your plugin ZIP for WordPress.org.
- If you use raster files, their colors come from the file itself.
- If you want colors controlled by the plugin color pickers, switch the icon source to `Inline SVG` in the plugin settings.