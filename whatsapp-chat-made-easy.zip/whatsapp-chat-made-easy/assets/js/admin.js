(function ($) {
	'use strict';

	function initColorPickers(scope) {
		scope.find('.wcme-color-field').each(function () {
			$(this).wpColorPicker();
		});
	}

	function getNextContactIndex(table) {
		var maxIndex = -1;

		table.querySelectorAll('tr[data-wcme-contact-row]').forEach(function (row) {
			var current = parseInt(row.getAttribute('data-wcme-contact-index'), 10);
			if (!Number.isNaN(current) && current > maxIndex) {
				maxIndex = current;
			}
		});

		return maxIndex + 1;
	}

	function addContactRow() {
		var template = document.getElementById('wcme-contact-template');
		var table = document.getElementById('wcme-contacts-table');

		if (!template || !table) {
			return;
		}

		var tbody = table.querySelector('tbody');
		var index = getNextContactIndex(table);
		var html = template.innerHTML.replace(/__INDEX__/g, String(index));
		var temp = document.createElement('tbody');
		temp.innerHTML = html.trim();
		var row = temp.firstElementChild;

		if (row) {
			row.setAttribute('data-wcme-contact-index', String(index));
			tbody.appendChild(row);
			$(row).find('.wcme-color-field').wpColorPicker();
		}
	}

	$(function () {
		initColorPickers($(document));

		$(document).on('click', '[data-wcme-add-contact]', function (event) {
			event.preventDefault();
			addContactRow();
		});

		$(document).on('click', '[data-wcme-remove-contact]', function (event) {
			event.preventDefault();
			$(this).closest('tr').remove();
		});
	});
}(jQuery));
