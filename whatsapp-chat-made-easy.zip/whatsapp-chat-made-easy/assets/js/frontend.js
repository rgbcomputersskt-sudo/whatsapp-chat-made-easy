(function () {
	'use strict';

	function closeAllPanels() {
		document.querySelectorAll('.wcme-chat.is-open').forEach(function (root) {
			root.classList.remove('is-open');
			var toggle = root.querySelector('[data-wcme-toggle]');
			if (toggle) {
				toggle.setAttribute('aria-expanded', 'false');
			}
		});
	}

	function initChat(root) {
		var autoOpen = root.getAttribute('data-wcme-auto-open') === '1';
		var delay = parseInt(root.getAttribute('data-wcme-delay'), 10);

		if (autoOpen && root.classList.contains('wcme-chat--mode-panel')) {
			window.setTimeout(function () {
				root.classList.add('is-open');
				var toggle = root.querySelector('[data-wcme-toggle]');
				if (toggle) {
					toggle.setAttribute('aria-expanded', 'true');
				}
			}, Number.isNaN(delay) ? 0 : delay);
		}
	}

	function initAllChats() {
		document.querySelectorAll('.wcme-chat').forEach(initChat);
	}

	document.addEventListener('click', function (event) {
		var toggle = event.target.closest('[data-wcme-toggle]');

		if (toggle) {
			event.preventDefault();
			var root = toggle.closest('.wcme-chat');
			if (!root) {
				return;
			}

			var isOpen = root.classList.contains('is-open');
			closeAllPanels();
			if (!isOpen) {
				root.classList.add('is-open');
				toggle.setAttribute('aria-expanded', 'true');
			} else {
				toggle.setAttribute('aria-expanded', 'false');
			}
			return;
		}

		if (!event.target.closest('.wcme-chat')) {
			closeAllPanels();
		}
	});

	document.addEventListener('keydown', function (event) {
		if ('Escape' === event.key) {
			closeAllPanels();
		}
	});

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', initAllChats);
	} else {
		initAllChats();
	}
}());
